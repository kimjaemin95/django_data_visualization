from django.apps import AppConfig


class VmsConfig(AppConfig):
    name = 'vms'
